#include "main.h"
#include "usb_host.h"
#include "STM32F4xx.h"

#define rccahblenR * ( (unsigned volatile int *)0x40023830)
#define gpiodmask 1<<3
#define gpiodModr *((unsigned volatile int* )0x40020c00)
#define gpiodP14mask 1<<28
#define gpiodP13mask 1<<26
#define gpiodP15mask 1<<30
#define gpiodP12mask 1<<24
#define gpiodOdr  *((unsigned volatile int *)0x40020c14)
#define gpiodp14onmask 1<<14
#define gpiodp14ofmask 0<<14
#define gpiodp13onmask 1<<13
#define gpiodp13ofmask ~(1<<13)
#define gpiodp15onmask 1<<15
#define gpiodp15ofmask 0<<15
#define gpiodp12onmask 1<<12
#define gpiodp12ofmask 0<<12

void SystemInnit(){
(*((int*)0xE000ED88))|=0x0F00000;
RCC->APB1ENR |= 0x00000010; //TIM1 enabled
TIM1->PSC = 0x0002; //the 16 bit PSC value is set to 2
TIM1->ARR = 0x7FFF; //the 16 bit ARR value is set to 65535

}
void init_led ();
void gang();


void init_led(){

rccahblenR = gpiodmask;
gpiodModr=gpiodP15mask;

}

void gang(){

gpiodOdr=gpiodp15onmask;

}

int main(){


while(1){

	for(int i=0; i<19170;i++){
		TIM1->CR1 = 0x0001; //DIR value is set to 0 to count up, will count exactly 19170 times which is my duration time.

	}

	TIM1->CR1 = 0x0000; //stops the timer after the loop
	TIM1->CNT = 0x0001; //set the count register to 1 to read

	gang(); //gang function enables the led (my ledpinnumber is 15, the blue led)

}


}
